package ar.org.centro8.curso.java.entities;

public class AutoClasico extends Auto {

    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    public AutoClasico(String marca, String modelo, String color, int precio) {

        super(marca, modelo, color, precio);

    }

    public AutoClasico(String marca, String modelo, String color, String marcaRadio) {
        super(marca, modelo, color, marcaRadio);
    }

    public AutoClasico(String marca, String modelo, String color, int precio, String marcaRadio) {
        super(marca, modelo, color, precio, marcaRadio);
    }

    @Override
    public String toString() {
        return "AutoClasico: " + super.toString();
    }

}
