package ar.org.centro8.curso.java.entities;

public class Radio {

    private String marcaradio;

    public Radio() {
    }

    public Radio(String marcaradio) {
        this.marcaradio = marcaradio;
    }

    @Override
    public String toString() {
        return "estado: " + marcaradio + "]";
    }

}
