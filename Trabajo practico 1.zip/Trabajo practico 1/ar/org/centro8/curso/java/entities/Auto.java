package ar.org.centro8.curso.java.entities;

public abstract class Auto {
    private Radio marcaRadio;
    private String marca;
    private String modelo;
    private String color;
    private int precio;

    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public Auto(String marca, String modelo, String color, int precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    public Auto(String marca, String modelo, String color, int precio, String marcaRadio) {

        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.marcaRadio = new Radio(marcaRadio);
    }

    public Auto(String marca, String modelo, String color, String marcaRadio) {

        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.marcaRadio = new Radio(marcaRadio);

    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void addRadio(String marcaRadio) {
        System.out.println("se le agregara una RADIO al auto");
        this.marcaRadio = new Radio(marcaRadio);
    }

    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", precio=" + precio
                + ", marcaRadio="
                + marcaRadio + "]";
    }

}
