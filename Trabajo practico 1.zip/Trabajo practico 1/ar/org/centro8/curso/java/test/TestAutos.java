package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.AutoNuevo;

public class TestAutos {

    public static void main(String[] args) {

        System.out.println(" Un Vehículo siempre tiene color marca modelo y no siempre tiene precio");
        AutoClasico autoclasico1 = new AutoClasico("mayo", "nesa", "amarillo");
        AutoNuevo autonuevo1 = new AutoNuevo("mercedes", "Wayne", "negro");
        System.out.println(autoclasico1);
        System.out.println(autonuevo1);
        System.out.println("--------------------------------------------------------------------------");
        System.out.println("un radio solo puede estar en un vehiculo a la vez");
        AutoClasico autoclasico2 = new AutoClasico("bentley", "HP", "gris", 500000, "este auto tiene radio");
        AutoNuevo autonuevo2 = new AutoNuevo("AL", "XL900", "Rosa", 7000, "este auto tiene radio");
        System.out.println(autonuevo2);
        System.out.println(autoclasico2);

        System.out.println("-----------------------------------------------------------------------------------");

        System.out.println("Un auto clasico se puede fabricar sin radio,despues se puede agregar el radio");

        AutoClasico autoclasico3 = new AutoClasico("X9", "Centurion", "azul");
        System.out.println(autoclasico3);
        autoclasico3.addRadio("este auto tiene radio ahora");
        System.out.println(autoclasico3);

        System.out.println("---------------------------------------------------------------------------------");

        System.out.println("Un Auto Nuevo siempre tiene Radio y se puede cambiar de Radio.");
        AutoNuevo autonuevo3 = new AutoNuevo("UP800", "Ulises", "plateado", "este auto tiene radio");
        System.out.println(autonuevo3);
        autonuevo3.addRadio("a este auto se le ha cambiado la radio");
        System.out.println(autonuevo3);

    }
}